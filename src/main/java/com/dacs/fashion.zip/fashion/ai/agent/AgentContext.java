package com.dacs.fashion.ai.agent;

import java.util.ArrayList;
import java.util.List;

public class AgentContext {
    private final List<Long> lastProductIds = new ArrayList<>();
    private final List<Long> lastVariantIds = new ArrayList<>();
    private final List<Long> lastCartItemIds = new ArrayList<>();
    private long updatedAt = System.currentTimeMillis();

    public List<Long> getLastProductIds() { return lastProductIds; }
    public List<Long> getLastVariantIds() { return lastVariantIds; }
    public List<Long> getLastCartItemIds() { return lastCartItemIds; }
    public long getUpdatedAt() { return updatedAt; }
    public void touch() { updatedAt = System.currentTimeMillis(); }
    public void clearProducts() { lastProductIds.clear(); lastVariantIds.clear(); touch(); }
    public void clearCart() { lastCartItemIds.clear(); touch(); }
}
