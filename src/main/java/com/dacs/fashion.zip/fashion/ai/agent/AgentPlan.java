package com.dacs.fashion.ai.agent;

import java.math.BigDecimal;
import java.util.List;

public record AgentPlan(
        String action,
        String productType,
        String audience,
        BigDecimal minPrice,
        BigDecimal maxPrice,
        BigDecimal targetPrice,
        BigDecimal totalBudget,
        String size,
        String color,
        String brand,
        String occasion,
        String style,
        Long productId,
        Long variantId,
        Long cartItemId,
        Long orderId,
        Integer quantity,
        String voucherCode,
        List<Integer> referenceIndexes,
        String reply
) {}
