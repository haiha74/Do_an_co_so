package com.dacs.fashion.ai.agent;

import com.dacs.fashion.ai.groq.GroqClient;
import com.dacs.fashion.ai.tool.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class JodokAgent {
    private static final long TTL_MS = 30 * 60 * 1000L;
    private final GroqClient groqClient;
    private final ObjectMapper objectMapper;
    private final ProductTool productTool;
    private final CartTool cartTool;
    private final OrderTool orderTool;
    private final VoucherTool voucherTool;
    private final StylistTool stylistTool;
    private final Map<String, AgentContext> contexts = new ConcurrentHashMap<>();

    public JodokAgent(GroqClient groqClient, ObjectMapper objectMapper, ProductTool productTool,
                      CartTool cartTool, OrderTool orderTool, VoucherTool voucherTool, StylistTool stylistTool) {
        this.groqClient = groqClient; this.objectMapper = objectMapper; this.productTool = productTool;
        this.cartTool = cartTool; this.orderTool = orderTool; this.voucherTool = voucherTool; this.stylistTool = stylistTool;
    }

    public AgentPlan plan(String message, String conversationId, Long userId) throws Exception {
        AgentContext context = context(conversationId);
        ProductTool.CatalogInfo info = productTool.getCatalogInfo();
        String prompt = """
                Bạn là router/tool planner của JODOK. Hiểu tiếng Việt tự nhiên, không dựa vào keyword cố định.
                Chỉ trả JSON object. action thuộc: PRODUCT_SEARCH, VARIANT_CHECK, COMPARE, OUTFIT,
                CART_VIEW, CART_ADD, CART_UPDATE, CART_REMOVE, CART_CLEAR,
                VOUCHER_LIST, VOUCHER_CHECK, ORDER_LIST, ORDER_VIEW, ORDER_CANCEL, CHAT, ASK_CLARIFICATION.
                Với giá: 'áo 100k' nghĩa là khoảng giá (minPrice=80000,maxPrice=120000,targetPrice=100000);
                chỉ dùng maxPrice=100000 khi khách nói dưới/không quá/tối đa 100k.
                productType phải là loại sản phẩm khách yêu cầu. Không tự bịa ID.
                Nếu nhắc mẫu N, đặt referenceIndexes là mảng số N (1-based).
                JSON phải khớp các field AgentPlan; field không biết để null.
                """
                + "\nAuthenticated=" + (userId != null)
                + "\nCategories=" + info.categories()
                + "\nBrands=" + info.brands()
                + "\nLastProductIds=" + context.getLastProductIds()
                + "\nLastVariantIds=" + context.getLastVariantIds()
                + "\nLastCartItemIds=" + context.getLastCartItemIds()
                + "\nUSER: " + message;
        JsonNode json = groqClient.callJson("Bạn là JODOK Agent Planner. Chỉ xuất JSON hợp lệ.", prompt, 700);
        if (json == null) throw new IllegalStateException("AI không trả về kế hoạch hợp lệ.");
        context.touch();
        return objectMapper.treeToValue(json, AgentPlan.class);
    }

    public AgentContext context(String conversationId) {
        String key = conversationId == null || conversationId.isBlank() ? "anonymous" : conversationId.trim();
        AgentContext current = contexts.get(key);
        if (current == null || System.currentTimeMillis() - current.getUpdatedAt() > TTL_MS) {
            current = new AgentContext(); contexts.put(key, current);
        }
        return current;
    }

    public ProductTool productTool() { return productTool; }
    public CartTool cartTool() { return cartTool; }
    public OrderTool orderTool() { return orderTool; }
    public VoucherTool voucherTool() { return voucherTool; }
    public StylistTool stylistTool() { return stylistTool; }
}
