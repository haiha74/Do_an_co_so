package com.dacs.fashion.ai.tool;

import com.dacs.fashion.dto.CartItemDTO;
import com.dacs.fashion.entity.Cart;
import com.dacs.fashion.entity.CartItem;
import com.dacs.fashion.service.CartService;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

@Component
public class CartTool {
    private final CartService cartService;
    public CartTool(CartService cartService) { this.cartService = cartService; }

    public Cart view(Long userId) { requireUser(userId); return cartService.getCart(userId); }

    public Cart add(Long userId, Long variantId, Integer quantity) {
        requireUser(userId);
        CartItemDTO dto = new CartItemDTO(userId, variantId, quantity == null ? 1 : quantity);
        return cartService.addToCart(dto);
    }

    public Cart update(Long userId, Long cartItemId, Integer quantity) {
        requireUser(userId); requireOwner(userId, cartItemId);
        return cartService.updateQuantity(cartItemId, quantity);
    }

    public Cart remove(Long userId, Long cartItemId) {
        requireUser(userId); requireOwner(userId, cartItemId);
        cartService.removeItem(cartItemId);
        return cartService.getCart(userId);
    }

    public Cart clear(Long userId) {
        requireUser(userId); cartService.clearCart(userId); return cartService.getCart(userId);
    }

    public List<CartItem> orderedItems(Long userId) {
        Cart cart = view(userId);
        if (cart.getItems() == null) return List.of();
        return cart.getItems().stream()
                .sorted(Comparator.comparing(CartItem::getCartItemId, Comparator.nullsLast(Long::compareTo)))
                .toList();
    }

    private void requireOwner(Long userId, Long itemId) {
        if (itemId == null || !cartService.isItemOwner(itemId, userId))
            throw new SecurityException("Bạn không có quyền thao tác sản phẩm này trong giỏ.");
    }
    private void requireUser(Long userId) {
        if (userId == null) throw new SecurityException("Vui lòng đăng nhập để sử dụng giỏ hàng.");
    }
}
