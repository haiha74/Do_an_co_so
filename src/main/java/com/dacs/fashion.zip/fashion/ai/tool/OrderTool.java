package com.dacs.fashion.ai.tool;

import com.dacs.fashion.entity.Order;
import com.dacs.fashion.service.OrderService;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;

@Component
public class OrderTool {
    private final OrderService orderService;
    public OrderTool(OrderService orderService) { this.orderService = orderService; }

    public List<Order> listMine(Long userId) {
        requireUser(userId);
        return orderService.getByUser(userId).stream()
                .sorted(Comparator.comparing(Order::getOrderId, Comparator.nullsLast(Long::compareTo)).reversed())
                .toList();
    }

    public Order getMine(Long userId, Long orderId) {
        requireUser(userId);
        if (orderId == null) throw new IllegalArgumentException("Thiếu mã đơn hàng.");
        Order order = orderService.getById(orderId);
        if (order.getUser() == null || !Objects.equals(order.getUser().getUserId(), userId))
            throw new SecurityException("Bạn không có quyền xem đơn hàng này.");
        return order;
    }

    public Order cancelMine(Long userId, Long orderId) {
        Order order = getMine(userId, orderId);
        String status = order.getOrderStatus();
        if ("COMPLETED".equalsIgnoreCase(status) || "CANCELLED".equalsIgnoreCase(status))
            throw new IllegalStateException("Đơn hàng ở trạng thái này không thể hủy.");
        return orderService.updateStatus(orderId, "CANCELLED", "CUSTOMER");
    }

    private void requireUser(Long userId) {
        if (userId == null) throw new SecurityException("Vui lòng đăng nhập để xem đơn hàng.");
    }
}
