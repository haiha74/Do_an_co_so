package com.dacs.fashion.ai.tool;

import com.dacs.fashion.entity.Brand;
import com.dacs.fashion.entity.Category;
import com.dacs.fashion.entity.Product;
import com.dacs.fashion.entity.ProductVariant;
import com.dacs.fashion.repository.ProductRepository;
import com.dacs.fashion.repository.ProductVariantRepository;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Product Tool của JODOK.
 *
 * Quy tắc kiến trúc:
 * - KHÔNG đọc raw message của khách.
 * - Groq/JodokAgent sẽ hiểu ngôn ngữ tự nhiên và tạo SearchRequest.
 * - Class này chỉ thực thi constraint có cấu trúc trên dữ liệu thật trong DB.
 * - Chỉ trả dữ liệu public cần thiết cho AI/UI.
 */
@Component
public class ProductTool {

    private static final int DEFAULT_LIMIT = 12;
    private static final int MAX_LIMIT = 30;

    private final ProductRepository productRepository;
    private final ProductVariantRepository variantRepository;

    public ProductTool(
            ProductRepository productRepository,
            ProductVariantRepository variantRepository
    ) {
        this.productRepository = productRepository;
        this.variantRepository = variantRepository;
    }

    public record SearchRequest(
            String productType,
            String audience,
            BigDecimal minPrice,
            BigDecimal maxPrice,
            BigDecimal targetPrice,
            String size,
            String color,
            String brand,
            String occasion,
            String style,
            Boolean stockOnly,
            Integer limit
    ) {
    }

    public record ProductCandidate(
            Long productId,
            Long variantId,
            String productName,
            String description,
            String category,
            String brand,
            BigDecimal price,
            String size,
            String color,
            Integer stock
    ) {
    }

    public record CatalogInfo(
            Set<String> categories,
            Set<String> brands
    ) {
    }

    /**
     * Search bằng structured arguments.
     * Không nhận message của người dùng.
     */
    public List<ProductCandidate> search(SearchRequest request) {

        SearchRequest safe = request == null
                ? new SearchRequest(
                        null, null,
                        null, null, null,
                        null, null, null,
                        null, null,
                        true, DEFAULT_LIMIT
                )
                : request;

        int limit = normalizeLimit(safe.limit());

        List<ProductCandidate> catalog = loadPublicCatalog();

        List<ProductCandidate> hardFiltered = catalog.stream()
                .filter(item -> Boolean.FALSE.equals(safe.stockOnly()) || item.stock() > 0)
                .filter(item -> safe.minPrice() == null
                        || item.price().compareTo(safe.minPrice()) >= 0)
                .filter(item -> safe.maxPrice() == null
                        || item.price().compareTo(safe.maxPrice()) <= 0)
                .filter(item -> isBlank(safe.size())
                        || sameText(item.size(), safe.size()))
                .filter(item -> isBlank(safe.color())
                        || semanticContains(item.color(), safe.color()))
                .filter(item -> isBlank(safe.brand())
                        || sameText(item.brand(), safe.brand()))
                .filter(item -> isBlank(safe.productType())
                        || matchesProductType(item, safe.productType()))
                .toList();

        /*
         * Một product có thể có nhiều variant.
         * Rank variant trước rồi chỉ giữ variant phù hợp nhất của mỗi product
         * để card không bị lặp cùng một sản phẩm.
         */
        List<ProductCandidate> ranked = new ArrayList<>(hardFiltered);

        ranked.sort(
                Comparator
                        .comparingInt(
                                (ProductCandidate item) ->
                                        semanticScore(item, safe)
                        )
                        .reversed()
                        .thenComparing(
                                item -> priceDistance(
                                        item.price(),
                                        safe.targetPrice()
                                )
                        )
                        .thenComparing(
                                ProductCandidate::productId,
                                Comparator.nullsLast(Long::compareTo)
                        )
                        .thenComparing(
                                ProductCandidate::variantId,
                                Comparator.nullsLast(Long::compareTo)
                        )
        );

        Map<Long, ProductCandidate> oneVariantPerProduct =
                new LinkedHashMap<>();

        for (ProductCandidate item : ranked) {

            if (item.productId() == null) {
                continue;
            }

            oneVariantPerProduct.putIfAbsent(
                    item.productId(),
                    item
            );

            if (oneVariantPerProduct.size() >= limit) {
                break;
            }
        }

        return List.copyOf(oneVariantPerProduct.values());
    }

    /**
     * Dùng cho câu hỏi như:
     * "Shop có những thương hiệu nào?"
     * "Có những danh mục gì?"
     */
    public CatalogInfo getCatalogInfo() {

        Set<String> categories = new LinkedHashSet<>();
        Set<String> brands = new LinkedHashSet<>();

        for (Product product : productRepository.findAll()) {

            if (!isProductActive(product)) {
                continue;
            }

            Category category = product.getCategory();
            Brand brand = product.getBrand();

            if (
                    category != null
                            && !isBlank(category.getCategoryName())
            ) {
                categories.add(
                        category.getCategoryName().trim()
                );
            }

            if (
                    brand != null
                            && !isBlank(brand.getBrandName())
            ) {
                brands.add(
                        brand.getBrandName().trim()
                );
            }
        }

        return new CatalogInfo(
                Set.copyOf(categories),
                Set.copyOf(brands)
        );
    }

    /**
     * Lấy các variant public của một product.
     * Sẽ dùng cho "mẫu 2 còn size L/màu đen không?".
     */
    public List<ProductCandidate> getVariants(Long productId) {

        if (productId == null) {
            return List.of();
        }

        return loadPublicCatalog().stream()
                .filter(item ->
                        Objects.equals(
                                item.productId(),
                                productId
                        )
                )
                .sorted(
                        Comparator
                                .comparing(
                                        ProductCandidate::price,
                                        Comparator.nullsLast(
                                                BigDecimal::compareTo
                                        )
                                )
                                .thenComparing(
                                        ProductCandidate::variantId,
                                        Comparator.nullsLast(
                                                Long::compareTo
                                        )
                                )
                )
                .toList();
    }

    /**
     * Lookup chính xác variant trước khi CartTool thao tác.
     */
    public ProductCandidate getVariant(Long variantId) {

        if (variantId == null) {
            return null;
        }

        ProductVariant variant =
                variantRepository.findById(variantId)
                        .orElse(null);

        if (!isVariantPublic(variant)) {
            return null;
        }

        return toCandidate(variant);
    }

    private List<ProductCandidate> loadPublicCatalog() {

        List<ProductCandidate> result = new ArrayList<>();

        /*
         * Dùng variantRepository làm nguồn chính vì giá/size/màu/stock
         * nằm trên ProductVariant trong project JODOK hiện tại.
         */
        for (ProductVariant variant : variantRepository.findAll()) {

            if (!isVariantPublic(variant)) {
                continue;
            }

            ProductCandidate candidate =
                    toCandidate(variant);

            if (candidate != null) {
                result.add(candidate);
            }
        }

        return result;
    }

    private ProductCandidate toCandidate(
            ProductVariant variant
    ) {

        if (variant == null || variant.getProduct() == null) {
            return null;
        }

        Product product = variant.getProduct();

        Category category = product.getCategory();
        Brand brand = product.getBrand();

        BigDecimal price =
                variant.getPrice() != null
                        ? variant.getPrice()
                        : product.getBasePrice();

        if (price == null) {
            return null;
        }

        return new ProductCandidate(
                product.getProductId(),
                variant.getVariantId(),
                safeText(product.getProductName()),
                trimDescription(product.getDescription()),
                category == null
                        ? ""
                        : safeText(category.getCategoryName()),
                brand == null
                        ? ""
                        : safeText(brand.getBrandName()),
                price,
                safeText(variant.getSize()),
                safeText(variant.getColor()),
                variant.getStock() == null
                        ? 0
                        : Math.max(variant.getStock(), 0)
        );
    }

    private boolean isVariantPublic(
            ProductVariant variant
    ) {

        if (variant == null || variant.getProduct() == null) {
            return false;
        }

        if (!isProductActive(variant.getProduct())) {
            return false;
        }

        String status = variant.getStatus();

        /*
         * Giữ tương thích dữ liệu cũ:
         * status null/blank vẫn được coi là usable,
         * giống logic CartService hiện tại.
         */
        return status == null
                || status.isBlank()
                || "ACTIVE".equalsIgnoreCase(status);
    }

    private boolean isProductActive(Product product) {

        if (product == null) {
            return false;
        }

        return "ACTIVE".equalsIgnoreCase(
                safeText(product.getStatus())
        );
    }

    /**
     * productType là output có cấu trúc của AI, không phải raw message.
     *
     * Ví dụ:
     * productType="áo"
     * sẽ match tên/category như "Áo thun", "Áo sơ mi",
     * nhưng không match "Tất", "Quần", "Váy".
     */
    private boolean matchesProductType(
            ProductCandidate item,
            String productType
    ) {

        String wanted = normalize(productType);

        if (wanted.isBlank()) {
            return true;
        }

        String name = normalize(item.productName());
        String category = normalize(item.category());

        if (
                containsPhrase(name, wanted)
                        || containsPhrase(category, wanted)
        ) {
            return true;
        }

        String combined =
                " " + name + " " + category + " ";

        for (String token : wanted.split("\\s+")) {

            if (token.length() < 2) {
                continue;
            }

            if (!combined.contains(" " + token + " ")) {
                return false;
            }
        }

        return true;
    }

    private int semanticScore(
            ProductCandidate item,
            SearchRequest request
    ) {

        int score = 0;

        if (
                !isBlank(request.productType())
                        && matchesProductType(
                                item,
                                request.productType()
                        )
        ) {
            score += 50;
        }

        if (
                !isBlank(request.audience())
                        && metadataContains(
                                item,
                                request.audience()
                        )
        ) {
            score += 18;
        }

        if (
                !isBlank(request.occasion())
                        && metadataContains(
                                item,
                                request.occasion()
                        )
        ) {
            score += 12;
        }

        if (
                !isBlank(request.style())
                        && metadataContains(
                                item,
                                request.style()
                        )
        ) {
            score += 10;
        }

        if (
                !isBlank(request.color())
                        && semanticContains(
                                item.color(),
                                request.color()
                        )
        ) {
            score += 10;
        }

        if (
                !isBlank(request.brand())
                        && sameText(
                                item.brand(),
                                request.brand()
                        )
        ) {
            score += 12;
        }

        if (
                !isBlank(request.size())
                        && sameText(
                                item.size(),
                                request.size()
                        )
        ) {
            score += 8;
        }

        if (item.stock() > 0) {
            score += 3;
        }

        return score;
    }

    private boolean metadataContains(
            ProductCandidate item,
            String value
    ) {

        String needle = normalize(value);

        if (needle.isBlank()) {
            return false;
        }

        String haystack = normalize(
                item.productName()
                        + " "
                        + item.description()
                        + " "
                        + item.category()
                        + " "
                        + item.brand()
                        + " "
                        + item.color()
        );

        return containsPhrase(
                haystack,
                needle
        );
    }

    private boolean semanticContains(
            String actual,
            String wanted
    ) {

        String left = normalize(actual);
        String right = normalize(wanted);

        if (right.isBlank()) {
            return true;
        }

        return containsPhrase(left, right)
                || containsPhrase(right, left);
    }

    private boolean sameText(
            String left,
            String right
    ) {
        return normalize(left)
                .equals(normalize(right));
    }

    private boolean containsPhrase(
            String text,
            String phrase
    ) {

        if (text == null || phrase == null) {
            return false;
        }

        String haystack =
                " " + normalize(text) + " ";

        String needle =
                " " + normalize(phrase) + " ";

        return haystack.contains(needle);
    }

    private BigDecimal priceDistance(
            BigDecimal price,
            BigDecimal target
    ) {

        if (price == null || target == null) {
            return BigDecimal.ZERO;
        }

        return price.subtract(target).abs();
    }

    private int normalizeLimit(Integer requested) {

        if (requested == null || requested <= 0) {
            return DEFAULT_LIMIT;
        }

        return Math.min(
                requested,
                MAX_LIMIT
        );
    }

    private String trimDescription(String value) {

        String text = safeText(value);

        if (text.length() <= 160) {
            return text;
        }

        return text.substring(0, 160) + "...";
    }

    private String safeText(String value) {
        return value == null
                ? ""
                : value.trim();
    }

    private boolean isBlank(String value) {
        return value == null
                || value.isBlank();
    }

    private String normalize(String value) {

        if (value == null) {
            return "";
        }

        String normalized =
                Normalizer.normalize(
                        value,
                        Normalizer.Form.NFD
                );

        normalized =
                normalized.replaceAll(
                        "\\p{M}+",
                        ""
                );

        normalized =
                normalized.toLowerCase(Locale.ROOT);

        normalized =
                normalized.replace('đ', 'd');

        normalized =
                normalized.replaceAll(
                        "[^a-z0-9]+",
                        " "
                );

        return normalized.trim()
                .replaceAll("\\s+", " ");
    }
}
