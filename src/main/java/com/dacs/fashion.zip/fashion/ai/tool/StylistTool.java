package com.dacs.fashion.ai.tool;

import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.List;

@Component
public class StylistTool {
    private final ProductTool productTool;
    public StylistTool(ProductTool productTool) { this.productTool = productTool; }

    public List<ProductTool.ProductCandidate> candidates(String audience, BigDecimal totalBudget, String color, String occasion, String style) {
        BigDecimal max = totalBudget == null ? null : totalBudget;
        return productTool.search(new ProductTool.SearchRequest(
                null, audience, null, max, null, null, color, null,
                occasion, style, true, 24
        ));
    }
}
