package com.dacs.fashion.service;

import com.dacs.fashion.ai.agent.AgentContext;
import com.dacs.fashion.ai.agent.AgentPlan;
import com.dacs.fashion.ai.agent.JodokAgent;
import com.dacs.fashion.ai.tool.ProductTool;
import com.dacs.fashion.controller.ChatbotController.ChatProduct;
import com.dacs.fashion.controller.ChatbotController.ChatResponse;
import com.dacs.fashion.entity.Cart;
import com.dacs.fashion.entity.CartItem;
import com.dacs.fashion.entity.Order;
import com.dacs.fashion.entity.Voucher;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class AgentChatbotService {

    private final JodokAgent agent;

    public AgentChatbotService(JodokAgent agent) {
        this.agent = agent;
    }

    public ChatResponse reply(
            String message,
            String conversationId,
            Long authenticatedUserId
    ) {
        if (message == null || message.isBlank()) {
            return response("Bạn cứ nói tự nhiên nhu cầu của mình nhé.");
        }

        String cid = normalizeConversationId(conversationId);

        try {
            AgentPlan plan = agent.plan(
                    message.trim(),
                    cid,
                    authenticatedUserId
            );

            if (plan == null || blank(plan.action())) {
                return response(
                        "Mình chưa hiểu rõ yêu cầu. Bạn có thể nói cụ thể hơn một chút nhé."
                );
            }

            String action = plan.action()
                    .trim()
                    .toUpperCase(Locale.ROOT);

            return switch (action) {
                case "PRODUCT_SEARCH" ->
                        productSearch(plan, cid);

                case "VARIANT_CHECK" ->
                        variantCheck(plan, cid);

                case "COMPARE" ->
                        compare(plan, cid);

                case "OUTFIT" ->
                        outfit(plan, cid);

                case "CART_VIEW" ->
                        cartView(authenticatedUserId, cid);

                case "CART_ADD" ->
                        cartAdd(plan, authenticatedUserId, cid);

                case "CART_UPDATE" ->
                        cartUpdate(plan, authenticatedUserId, cid);

                case "CART_REMOVE" ->
                        cartRemove(plan, authenticatedUserId, cid);

                case "CART_CLEAR" ->
                        cartClear(authenticatedUserId, cid);

                case "VOUCHER_LIST" ->
                        voucherList();

                case "VOUCHER_CHECK" ->
                        voucherCheck(plan);

                case "ORDER_LIST" ->
                        orderList(authenticatedUserId);

                case "ORDER_VIEW" ->
                        orderView(plan, authenticatedUserId);

                case "ORDER_CANCEL" ->
                        orderCancel(plan, authenticatedUserId);

                case "ASK_CLARIFICATION" ->
                        response(
                                !blank(plan.reply())
                                        ? plan.reply()
                                        : "Bạn cho mình thêm một chút thông tin nhé."
                        );

                case "CHAT" ->
                        response(
                                !blank(plan.reply())
                                        ? plan.reply()
                                        : "Mình là trợ lý mua sắm JODOK. Bạn muốn tìm sản phẩm, phối đồ, xem giỏ hàng hay đơn hàng?"
                        );

                default ->
                        response(
                                !blank(plan.reply())
                                        ? plan.reply()
                                        : "Mình chưa hỗ trợ thao tác này."
                        );
            };

        } catch (SecurityException ex) {
            return response(
                    safeError(
                            ex,
                            "Vui lòng đăng nhập để sử dụng chức năng này."
                    )
            );

        } catch (IllegalArgumentException | IllegalStateException ex) {
            return response(
                    safeError(
                            ex,
                            "Mình chưa thể thực hiện yêu cầu này."
                    )
            );

        } catch (Exception ex) {
            System.err.println(
                    "[AGENT_CHATBOT] "
                            + ex.getClass().getSimpleName()
                            + ": "
                            + ex.getMessage()
            );

            return response(
                    "Trợ lý JODOK đang gặp lỗi khi xử lý yêu cầu. Bạn thử lại nhé."
            );
        }
    }

    public ChatResponse reply(
            String message,
            String conversationId
    ) {
        return reply(message, conversationId, null);
    }

    public ChatResponse reply(String message) {
        return reply(message, "anonymous", null);
    }

    // =========================================================
    // PRODUCT
    // =========================================================

    private ChatResponse productSearch(
            AgentPlan plan,
            String conversationId
    ) {
        List<ProductTool.ProductCandidate> items =
                agent.productTool().search(
                        new ProductTool.SearchRequest(
                                plan.productType(),
                                plan.audience(),
                                plan.minPrice(),
                                plan.maxPrice(),
                                plan.targetPrice(),
                                plan.size(),
                                plan.color(),
                                plan.brand(),
                                plan.occasion(),
                                plan.style(),
                                true,
                                12
                        )
                );

        if (items.isEmpty()) {
            clearProductContext(conversationId);

            return response(
                    !blank(plan.reply())
                            ? plan.reply()
                            : "Mình chưa tìm thấy sản phẩm phù hợp với yêu cầu đó."
            );
        }

        rememberProducts(conversationId, items);

        String reply =
                !blank(plan.reply())
                        ? plan.reply()
                        : "Mình tìm thấy "
                        + items.size()
                        + " sản phẩm phù hợp. Bạn có thể nói “mẫu 1”, “mẫu 2” để hỏi tiếp.";

        return new ChatResponse(
                reply,
                toChatProducts(items)
        );
    }

    private ChatResponse variantCheck(
            AgentPlan plan,
            String conversationId
    ) {
        Long productId =
                resolveProductId(plan, conversationId);

        if (productId == null) {
            return response(
                    "Bạn muốn kiểm tra mẫu nào? Hãy nói ví dụ “mẫu 1 còn size L không?”."
            );
        }

        List<ProductTool.ProductCandidate> variants =
                agent.productTool()
                        .getVariants(productId)
                        .stream()
                        .filter(v ->
                                blank(plan.size())
                                        || equalsIgnoreCase(
                                                v.size(),
                                                plan.size()
                                        )
                        )
                        .filter(v ->
                                blank(plan.color())
                                        || containsIgnoreCase(
                                                v.color(),
                                                plan.color()
                                        )
                        )
                        .toList();

        if (variants.isEmpty()) {
            return response(
                    "Mẫu này hiện không có biến thể phù hợp với size/màu bạn hỏi."
            );
        }

        rememberProducts(
                conversationId,
                variants
        );

        ProductTool.ProductCandidate first =
                variants.get(0);

        String reply =
                "Mẫu "
                        + first.productName()
                        + " có "
                        + variants.size()
                        + " biến thể phù hợp đang được ghi nhận.";

        return new ChatResponse(
                reply,
                toChatProducts(variants)
        );
    }

    private ChatResponse compare(
            AgentPlan plan,
            String conversationId
    ) {
        List<Long> ids =
                resolveProductIds(
                        plan,
                        conversationId
                );

        if (ids.size() < 2) {
            return response(
                    "Bạn chọn ít nhất 2 mẫu để mình so sánh nhé, ví dụ “so sánh mẫu 1 và mẫu 2”."
            );
        }

        List<ProductTool.ProductCandidate> selected =
                new ArrayList<>();

        for (Long productId : ids) {
            List<ProductTool.ProductCandidate> variants =
                    agent.productTool()
                            .getVariants(productId);

            if (!variants.isEmpty()) {
                selected.add(
                        variants.get(0)
                );
            }
        }

        if (selected.size() < 2) {
            return response(
                    "Mình chưa lấy đủ dữ liệu của các mẫu để so sánh."
            );
        }

        rememberProducts(
                conversationId,
                selected
        );

        StringBuilder text =
                new StringBuilder(
                        "So sánh nhanh:\n"
                );

        for (int i = 0; i < selected.size(); i++) {
            ProductTool.ProductCandidate p =
                    selected.get(i);

            text.append(i + 1)
                    .append(". ")
                    .append(p.productName())
                    .append(" — ")
                    .append(formatMoney(p.price()))
                    .append(", size ")
                    .append(emptyAs(p.size(), "chưa rõ"))
                    .append(", màu ")
                    .append(emptyAs(p.color(), "chưa rõ"))
                    .append(", tồn ")
                    .append(p.stock())
                    .append(".\n");
        }

        return new ChatResponse(
                text.toString().trim(),
                toChatProducts(selected)
        );
    }

    private ChatResponse outfit(
            AgentPlan plan,
            String conversationId
    ) {
        List<ProductTool.ProductCandidate> candidates =
                agent.stylistTool().candidates(
                        plan.audience(),
                        plan.totalBudget(),
                        plan.color(),
                        plan.occasion(),
                        plan.style()
                );

        if (candidates.isEmpty()) {
            return response(
                    "Mình chưa tìm được bộ phối phù hợp với yêu cầu và ngân sách đó."
            );
        }

        List<ProductTool.ProductCandidate> selected =
                candidates.stream()
                        .limit(6)
                        .toList();

        rememberProducts(
                conversationId,
                selected
        );

        return new ChatResponse(
                !blank(plan.reply())
                        ? plan.reply()
                        : "Mình gợi ý các món dưới đây để bạn phối outfit. Bạn có thể hỏi tiếp theo số mẫu.",
                toChatProducts(selected)
        );
    }

    // =========================================================
    // CART
    // =========================================================

    private ChatResponse cartView(
            Long userId,
            String conversationId
    ) {
        List<CartItem> items =
                agent.cartTool()
                        .orderedItems(userId);

        rememberCart(
                conversationId,
                items
        );

        if (items.isEmpty()) {
            return response(
                    "Giỏ hàng của bạn đang trống."
            );
        }

        return response(
                "Giỏ hàng hiện có "
                        + items.size()
                        + " dòng sản phẩm."
        );
    }

    private ChatResponse cartAdd(
            AgentPlan plan,
            Long userId,
            String conversationId
    ) {
        Long variantId =
                resolveVariantId(
                        plan,
                        conversationId
                );

        if (variantId == null) {
            Long productId =
                    resolveProductId(
                            plan,
                            conversationId
                    );

            if (productId != null) {
                List<ProductTool.ProductCandidate> variants =
                        agent.productTool()
                                .getVariants(productId)
                                .stream()
                                .filter(v ->
                                        blank(plan.size())
                                                || equalsIgnoreCase(
                                                        v.size(),
                                                        plan.size()
                                                )
                                )
                                .filter(v ->
                                        blank(plan.color())
                                                || containsIgnoreCase(
                                                        v.color(),
                                                        plan.color()
                                                )
                                )
                                .filter(v ->
                                        v.stock() != null
                                                && v.stock() > 0
                                )
                                .toList();

                if (variants.size() == 1) {
                    variantId =
                            variants.get(0)
                                    .variantId();
                } else if (variants.size() > 1) {
                    return new ChatResponse(
                            "Mẫu này có nhiều biến thể. Bạn chọn thêm size hoặc màu trước khi thêm vào giỏ nhé.",
                            toChatProducts(variants)
                    );
                }
            }
        }

        if (variantId == null) {
            return response(
                    "Bạn muốn thêm mẫu nào vào giỏ? Nếu sản phẩm có nhiều biến thể, hãy cho mình cả size hoặc màu."
            );
        }

        ProductTool.ProductCandidate variant =
                agent.productTool()
                        .getVariant(variantId);

        if (variant == null) {
            return response(
                    "Biến thể sản phẩm này không còn khả dụng."
            );
        }

        int quantity =
                plan.quantity() == null
                        ? 1
                        : Math.max(
                                1,
                                plan.quantity()
                        );

        if (variant.stock() < quantity) {
            return response(
                    "Sản phẩm chỉ còn "
                            + variant.stock()
                            + " sản phẩm trong kho."
            );
        }

        agent.cartTool()
                .add(
                        userId,
                        variantId,
                        quantity
                );

        rememberCart(
                conversationId,
                agent.cartTool()
                        .orderedItems(userId)
        );

        return response(
                "Đã thêm "
                        + quantity
                        + " × "
                        + variant.productName()
                        + " ("
                        + emptyAs(
                                variant.size(),
                                "không rõ size"
                        )
                        + ", "
                        + emptyAs(
                                variant.color(),
                                "không rõ màu"
                        )
                        + ") vào giỏ hàng."
        );
    }

    private ChatResponse cartUpdate(
            AgentPlan plan,
            Long userId,
            String conversationId
    ) {
        Long cartItemId =
                resolveCartItemId(
                        plan,
                        conversationId
                );

        if (cartItemId == null) {
            return response(
                    "Bạn muốn đổi sản phẩm nào trong giỏ?"
            );
        }

        if (plan.quantity() == null) {
            return response(
                    "Bạn muốn đổi số lượng thành bao nhiêu?"
            );
        }

        if (plan.quantity() <= 0) {
            return response(
                    "Số lượng phải lớn hơn 0."
            );
        }

        agent.cartTool()
                .update(
                        userId,
                        cartItemId,
                        plan.quantity()
                );

        rememberCart(
                conversationId,
                agent.cartTool()
                        .orderedItems(userId)
        );

        return response(
                "Đã cập nhật số lượng trong giỏ thành "
                        + plan.quantity()
                        + "."
        );
    }

    private ChatResponse cartRemove(
            AgentPlan plan,
            Long userId,
            String conversationId
    ) {
        Long cartItemId =
                resolveCartItemId(
                        plan,
                        conversationId
                );

        if (cartItemId == null) {
            return response(
                    "Bạn muốn xóa sản phẩm nào khỏi giỏ?"
            );
        }

        agent.cartTool()
                .remove(
                        userId,
                        cartItemId
                );

        rememberCart(
                conversationId,
                agent.cartTool()
                        .orderedItems(userId)
        );

        return response(
                "Đã xóa sản phẩm khỏi giỏ hàng."
        );
    }

    private ChatResponse cartClear(
            Long userId,
            String conversationId
    ) {
        agent.cartTool()
                .clear(userId);

        agent.context(conversationId)
                .clearCart();

        return response(
                "Đã xóa toàn bộ giỏ hàng."
        );
    }

    // =========================================================
    // VOUCHER
    // =========================================================

    private ChatResponse voucherList() {
        List<Voucher> vouchers =
                agent.voucherTool()
                        .active();

        if (vouchers.isEmpty()) {
            return response(
                    "Hiện chưa có voucher đang hoạt động."
            );
        }

        return response(
                "Hiện có "
                        + vouchers.size()
                        + " voucher đang hoạt động. Bạn có thể đưa mã voucher để mình kiểm tra."
        );
    }

    private ChatResponse voucherCheck(
            AgentPlan plan
    ) {
        if (blank(plan.voucherCode())) {
            return response(
                    "Bạn gửi mình mã voucher cần kiểm tra nhé."
            );
        }

        agent.voucherTool()
                .validate(
                        plan.voucherCode(),
                        plan.totalBudget() == null
                                ? BigDecimal.ZERO
                                : plan.totalBudget()
                );

        return response(
                "Mã "
                        + plan.voucherCode()
                        + " hợp lệ với giá trị đơn hàng đã cung cấp."
        );
    }

    // =========================================================
    // ORDER
    // =========================================================

    private ChatResponse orderList(
            Long userId
    ) {
        List<Order> orders =
                agent.orderTool()
                        .listMine(userId);

        if (orders.isEmpty()) {
            return response(
                    "Bạn chưa có đơn hàng nào."
            );
        }

        StringBuilder text =
                new StringBuilder(
                        "Các đơn hàng gần đây của bạn:\n"
                );

        int count =
                Math.min(
                        orders.size(),
                        8
                );

        for (int i = 0; i < count; i++) {
            Order order =
                    orders.get(i);

            text.append(i + 1)
                    .append(". Đơn #")
                    .append(order.getOrderId())
                    .append(" — ")
                    .append(
                            emptyAs(
                                    order.getOrderStatus(),
                                    "chưa rõ trạng thái"
                            )
                    )
                    .append("\n");
        }

        return response(
                text.toString().trim()
        );
    }

    private ChatResponse orderView(
            AgentPlan plan,
            Long userId
    ) {
        Long orderId =
                plan.orderId();

        if (orderId == null) {
            List<Order> orders =
                    agent.orderTool()
                            .listMine(userId);

            if (orders.isEmpty()) {
                return response(
                        "Bạn chưa có đơn hàng nào."
                );
            }

            orderId =
                    orders.get(0)
                            .getOrderId();
        }

        Order order =
                agent.orderTool()
                        .getMine(
                                userId,
                                orderId
                        );

        return response(
                "Đơn #"
                        + order.getOrderId()
                        + " hiện có trạng thái: "
                        + emptyAs(
                                order.getOrderStatus(),
                                "chưa rõ"
                        )
                        + "."
        );
    }

    private ChatResponse orderCancel(
            AgentPlan plan,
            Long userId
    ) {
        if (plan.orderId() == null) {
            return response(
                    "Bạn cho mình mã đơn hàng cần hủy nhé."
            );
        }

        Order order =
                agent.orderTool()
                        .cancelMine(
                                userId,
                                plan.orderId()
                        );

        return response(
                "Đơn #"
                        + order.getOrderId()
                        + " đã được cập nhật trạng thái "
                        + emptyAs(
                                order.getOrderStatus(),
                                "CANCELLED"
                        )
                        + "."
        );
    }

    // =========================================================
    // CONTEXT / REFERENCES
    // =========================================================

    private void rememberProducts(
            String conversationId,
            List<ProductTool.ProductCandidate> items
    ) {
        AgentContext context =
                agent.context(conversationId);

        context.clearProducts();

        for (ProductTool.ProductCandidate item : items) {
            context.getLastProductIds()
                    .add(item.productId());

            context.getLastVariantIds()
                    .add(item.variantId());
        }

        context.touch();
    }

    private void clearProductContext(
            String conversationId
    ) {
        agent.context(conversationId)
                .clearProducts();
    }

    private void rememberCart(
            String conversationId,
            List<CartItem> items
    ) {
        AgentContext context =
                agent.context(conversationId);

        context.clearCart();

        for (CartItem item : items) {
            if (item != null && item.getCartItemId() != null) {
                context.getLastCartItemIds()
                        .add(item.getCartItemId());
            }
        }

        context.touch();
    }

    private Long resolveProductId(
            AgentPlan plan,
            String conversationId
    ) {
        if (plan.productId() != null) {
            return plan.productId();
        }

        Integer index =
                firstReference(
                        plan.referenceIndexes()
                );

        if (index == null) {
            return null;
        }

        List<Long> ids =
                agent.context(conversationId)
                        .getLastProductIds();

        return atOneBased(
                ids,
                index
        );
    }

    private List<Long> resolveProductIds(
            AgentPlan plan,
            String conversationId
    ) {
        if (
                plan.referenceIndexes() == null
                        || plan.referenceIndexes()
                        .isEmpty()
        ) {
            return plan.productId() == null
                    ? List.of()
                    : List.of(
                            plan.productId()
                    );
        }

        List<Long> remembered =
                agent.context(conversationId)
                        .getLastProductIds();

        List<Long> result =
                new ArrayList<>();

        for (Integer index : plan.referenceIndexes()) {
            Long id =
                    atOneBased(
                            remembered,
                            index
                    );

            if (
                    id != null
                            && !result.contains(id)
            ) {
                result.add(id);
            }
        }

        return result;
    }

    private Long resolveVariantId(
            AgentPlan plan,
            String conversationId
    ) {
        if (plan.variantId() != null) {
            return plan.variantId();
        }

        Integer index =
                firstReference(
                        plan.referenceIndexes()
                );

        if (index == null) {
            return null;
        }

        return atOneBased(
                agent.context(conversationId)
                        .getLastVariantIds(),
                index
        );
    }

    private Long resolveCartItemId(
            AgentPlan plan,
            String conversationId
    ) {
        if (plan.cartItemId() != null) {
            return plan.cartItemId();
        }

        Integer index =
                firstReference(
                        plan.referenceIndexes()
                );

        if (index == null) {
            return null;
        }

        return atOneBased(
                agent.context(conversationId)
                        .getLastCartItemIds(),
                index
        );
    }

    private Integer firstReference(
            List<Integer> indexes
    ) {
        if (indexes == null || indexes.isEmpty()) {
            return null;
        }

        return indexes.get(0);
    }

    private <T> T atOneBased(
            List<T> values,
            Integer index
    ) {
        if (
                values == null
                        || index == null
                        || index < 1
                        || index > values.size()
        ) {
            return null;
        }

        return values.get(index - 1);
    }

    // =========================================================
    // RESPONSE HELPERS
    // =========================================================

    private List<ChatProduct> toChatProducts(
            List<ProductTool.ProductCandidate> items
    ) {
        if (items == null || items.isEmpty()) {
            return List.of();
        }

        return items.stream()
                .map(this::toChatProduct)
                .toList();
    }

    private ChatProduct toChatProduct(
            ProductTool.ProductCandidate item
    ) {
        return new ChatProduct(
                item.productId(),
                item.variantId(),
                item.productName(),
                item.price(),
                item.size(),
                item.color(),
                item.stock()
        );
    }

    private ChatResponse response(
            String text
    ) {
        return new ChatResponse(
                text,
                List.of()
        );
    }

    private String normalizeConversationId(
            String conversationId
    ) {
        return blank(conversationId)
                ? "anonymous"
                : conversationId.trim();
    }

    private boolean blank(String value) {
        return value == null
                || value.isBlank();
    }

    private boolean equalsIgnoreCase(
            String left,
            String right
    ) {
        return left != null
                && right != null
                && left.trim()
                .equalsIgnoreCase(
                        right.trim()
                );
    }

    private boolean containsIgnoreCase(
            String left,
            String right
    ) {
        return left != null
                && right != null
                && left.toLowerCase(Locale.ROOT)
                .contains(
                        right.toLowerCase(Locale.ROOT)
                );
    }

    private String emptyAs(
            String value,
            String fallback
    ) {
        return blank(value)
                ? fallback
                : value.trim();
    }

    private String safeError(
            Exception ex,
            String fallback
    ) {
        return ex.getMessage() == null
                || ex.getMessage().isBlank()
                ? fallback
                : ex.getMessage();
    }

    private String formatMoney(
            BigDecimal value
    ) {
        if (value == null) {
            return "chưa rõ giá";
        }

        return String.format(
                Locale.US,
                "%,.0fđ",
                value
        );
    }
}
